const http = require('http');
const moment = require('moment');

const port = 3003;
const server = http.createServer(function(request, response) {
    response.writeHead(200, {'Content-Type': 'text/html'});
    console.log(request.url);
    let res = 'Hello Node.js Server! <br><br>';
    res += '<h1 style="color: blue;">Version: ' + process.version + '</h1>';
    res += 'env: ' + JSON.stringify(process.env);
    res += `<h2 style="color: red;">${moment().format("dddd, MMMM Do YYYY, h:mm:ss a")}</h2>`;
    response.end(res);
});
server.listen(port, (err) => {
    if (err) {
        return console.log('something bad happened', err)
    }
    console.log(`server is listening on ${port}`);
    console.log(`Node.js version is ${process.version}`);
    console.log('===>', 'process.env: ' + JSON.stringify(process.env));
});
