// содежимое index.js
const http = require('http');
const moment = require('moment');

const requestHandler = (request, response) => {
    response.writeHead(200, {'Content-Type': 'text/html'});
    console.log(request.url);
    let x = 'Hello, Node.js Server! Version: ' + process.version + "<br><br>";
    x += 'process.env: ' + JSON.stringify(process.env);
    x += '<h1 style="color: blue;">Test title</h1>';
    x += `<h2 style="color: green;">${moment().format("dddd, MMMM Do YYYY, h:mm:ss a")}</h2>`;
    response.end(x);
};
const server = http.createServer(requestHandler);
server.listen();